package org.servlet.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.servlet.model.Book;
import org.servlet.model.Library;

@WebServlet("/save")
public class SaveServlet extends HttpServlet 
{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
	int libraryId	=Integer.parseInt(req.getParameter("li"));
	int bookId	=Integer.parseInt(req.getParameter("bi"));
	String bookName=req.getParameter("bn");
	String author=req.getParameter("a");
	String publisher=req.getParameter("p");
		
	HttpSession session=req.getSession();
	session.setAttribute("bookId", bookId);
	List<Book>  book =(List<Book>) new Book();
	((Book) book).setBookId(bookId);
	((Book) book).setBookName(bookName);
	((Book) book).setPublisher(publisher);
	((Book) book).setAuthor(author);
		
	Library library=new Library();
	library.setBooks(book);
	PrintWriter out=res.getWriter();
	out.println(book +"succesfully saved ");
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("Servlets_JSP_Demo");
	EntityManager manager=factory.createEntityManager();
	manager.getTransaction().begin();
	manager.persist(book);
	manager.getTransaction().commit();
		
	}
}
