package org.servlet.com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.servlet.model.Book;


@WebServlet("/update")
public class Update extends HttpServlet {
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		int bookId	=Integer.parseInt(req.getParameter("bi"));
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("Servlets_JSP_Demo");
		EntityManager manager=factory.createEntityManager();
		manager.getTransaction().begin();
		Book book;
		book=manager.find(Book.class, bookId);
		
		String bookName=req.getParameter("bn");
		book.setBookName(bookName);
		manager.getTransaction().commit();
		
		PrintWriter out=res.getWriter();
		out.println(book +"succesfully updated ");
		
		

	}

	

}
