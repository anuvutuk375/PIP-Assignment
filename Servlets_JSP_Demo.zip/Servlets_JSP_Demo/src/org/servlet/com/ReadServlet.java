package org.servlet.com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.servlet.model.Book;

@WebServlet("/read")
public class ReadServlet extends HttpServlet 
{
	 public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException
	 {
		 
		 EntityManagerFactory factory=Persistence.createEntityManagerFactory("Servlets_JSP_Demo");
			EntityManager manager=factory.createEntityManager();
			
			manager.getTransaction().begin();
			
			int bookId	=Integer.parseInt(req.getParameter("bi"));
			Book book;
			book=manager.find(Book.class, bookId);
			
			manager.getTransaction().commit();
			
			PrintWriter out=res.getWriter();
			out.println(book +" your required book details");
			
			
		 
	 }
}
