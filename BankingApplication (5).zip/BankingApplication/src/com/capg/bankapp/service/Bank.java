package com.capg.bankapp.service;

import java.util.Scanner;

import com.capg.bankapp.Account;
import com.capg.bankapp.service.BankService;



public class Bank {
	BankService bankServiceObj = new BankService();
	Scanner sc = new Scanner(System.in);
		
	public void createAccount() 
	{
	System.out.print("Enter Name: ");
	String name = sc.next();
	System.out.print("Enter addres:");
	String address = sc.next();
	int Id=(int) ((Math.random() * ((9999999 - 999) + 1)) + 999); 
	Account bankBeanObjCreateAccountObj = new Account(Id, name, address);
	System.out.println("Account Is created with Account Number: " +Id);
	bankServiceObj.bankAccountCreate(bankBeanObjCreateAccountObj);
	}
	public void showAccountDetails() {
	System.out.println("account details");
		
	}
public void payLoan() {
	
}
	public void deposit()
	{
	System.out.print("Enter Account Id: ");
	int Id = sc.nextInt();
	System.out.print("Enter Deposit Amount: ");
	double depAmount = sc.nextDouble();
	Account bankBeanDeptObj = new Account(Id, depAmount);
	bankServiceObj.depositSer(bankBeanDeptObj);
	}
	public void withdraw() 
	{
	System.out.print("Enter Account Id: ");
	int Id = sc.nextInt();
	System.out.print("Enter Withdraw Amount: ");
	float withdrawAmount = sc.nextFloat();
	Account bankBeanWithdrawObj = new Account(withdrawAmount, Id);
	bankServiceObj.withdrawSer(bankBeanWithdrawObj);
	}


}
