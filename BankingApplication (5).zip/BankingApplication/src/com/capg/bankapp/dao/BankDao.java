package com.capg.bankapp.dao;

import java.util.HashMap;

import com.capg.bankapp.Account;
import com.capg.bankapp.Loan;

public class BankDao {
	Account accountobj;
	Loan loanobj;
	HashMap<Integer, Account> hashmap1= new HashMap<Integer, Account>(); 
	HashMap<Integer, Loan> hashmap2= new HashMap<Integer, Loan>(); 

	
	public void getDetails(Account Accountobj)
	{
	this.accountobj = Accountobj;
	hashmap1.put(accountobj.getId(), Accountobj); 
	}
	 public HashMap<Integer, Account> showDetails(){  
	return hashmap1;
	 }
public void getLoan(Loan Loanobj) {
	this.loanobj=Loanobj;
	hashmap2.put(loanobj.getLoadId(), Loanobj);
}
public HashMap<Integer,Loan>showLoanDetails(){
	return hashmap2;
}

}
