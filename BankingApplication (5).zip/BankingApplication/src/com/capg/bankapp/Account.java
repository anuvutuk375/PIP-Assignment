package com.capg.bankapp;

public class Account {
	private int Id;
	private String Name;
private String address;
private double deposit;
private double balance;
private double withdrawamount;

	public Account(int id, String name, String address) {
	super();
	Id = id;
	Name = name;
	this.address = address;
}
	public int getId() {
	return Id;
}
public void setId(int id) {
	Id = id;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public double getDeposit() {
	return deposit;
}
public void setDeposit(double deposit) {
	this.deposit = deposit;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public double getWithdrawamount() {
	return withdrawamount;
}
public void setWithdrawamount(double withdrawamount) {
	this.withdrawamount = withdrawamount;
}
 public Account(int Id, double deposit) { 
		this.Id = Id;
		this.deposit = deposit;
		}
		public Account(double withdrawamount, int Id) {
		this.withdrawamount = withdrawamount;
		this.Id = Id;
		}

}
