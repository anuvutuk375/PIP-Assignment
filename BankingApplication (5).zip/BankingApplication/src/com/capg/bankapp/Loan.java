package com.capg.bankapp;

public class Loan {
	private int loadId;
	private String loanType;
	private double loanAmount;
	public Loan(int loadId, String loanType, double loanAmount) {
		super();
		this.loadId = loadId;
		this.loanType = loanType;
		this.loanAmount = loanAmount;
	}
	public int getLoadId() {
		return loadId;
	}
	public void setLoadId(int loadId) {
		this.loadId = loadId;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	@Override
	public String toString() {
		return "Loan [loadId=" + loadId + ", loanType=" + loanType + ", loanAmount=" + loanAmount + "]";
	}

	}


