package com.emp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



import com.emp.app.Employee;

public class EmpService
{List<Employee> list=new ArrayList<Employee>();
	Scanner sc = new Scanner(System.in);
public List<Employee> saveEmployee()
{
	Scanner sc = new Scanner(System.in);
	
	System.out.println("enter employee first  name");
	String fname = sc.next();
	
	System.out.println("enter employee last  name");
	String lname = sc.next();
	
	System.out.print("Enter addres:");
	String address = sc.next();
	
	int empId=(int) ((Math.random() * ((9999999 - 999) + 1)) + 999); 
	String s1=Integer.toString(empId);
	System.out.println("your employee Id" +s1);
	
	System.out.print("Enter salary:");
	
	int salary= sc.nextInt();
	String sal=Integer.toString(salary);
	
	System.out.print("Enter date of joining:");
	String doj= sc.next();
	
	Employee employee= new Employee(s1, fname, lname, sal, doj);

	list.add(employee);
	System.out.println(list);
	return list;
	}

public List<Employee> searchEmpById()
{
	
	Scanner sc4=new Scanner(System.in);
	System.out.println("search emp based on id");
	int s4=sc4.nextInt();
	
	String s1=Integer.toString(s4);
	
	for(Employee emp: list) {
		if((emp.getEmployeeId().equals(s1))) 
			System.out.println(emp);
		}
	
	return null;
}

public List<Employee> searchByFirstName()
{
	
	Scanner fname=new Scanner(System.in);
	System.out.println("search emp based on first name");
	String fname1=fname.next();
	
	
	
	for(Employee emp: list) {
		if((emp.getFirstName().equals(fname1))) 
			System.out.println(emp);
		}
	
	return null;
	}

public List<Employee> searchByLastName()
{
	
	Scanner lname=new Scanner(System.in);
	System.out.println("search emp based on last name");
	String lname1=lname.next();
	for(Employee emp: list) {
		if((emp.getFirstName().equals(lname1))) 
			System.out.println(emp);
		}
	
	return null;
	}

public List<Employee> searchBySalary()
{
	
	Scanner sal=new Scanner(System.in);
	System.out.println("search emp based on salary");
	String sal1=sal.next();
	for(Employee emp: list) {
		if((emp.getFirstName().equals(sal1))) 
			System.out.println(emp);
		}
	
	return null;
	}




}





