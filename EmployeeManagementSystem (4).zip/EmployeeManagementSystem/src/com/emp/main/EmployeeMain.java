package com.emp.main;

import java.util.List;
import java.util.Scanner;

import com.emp.app.Employee;
import com.emp.service.EmpService;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ch;
		EmpService service = new EmpService();
		Scanner sc = new Scanner(System.in);
	
		while(true)
		{
			System.out.println("\n ------------------\n 1. Save Employee information \n 2. Sort Employee \n 3.Exit \n -----------------------");
			System.out.print("Enter your choice : ");
			ch = sc.nextInt(); 
	
			switch(ch) {
			case 1:
				service.saveEmployee();
			break;
			case 2: 
			
				service.searchEmpById();
				service.searchByFirstName();
				service.searchByLastName();
				service.searchBySalary();
				
				
				
				
			break;
			case 3:
				System.out.println("Thank You !");
			    System.exit(0);
			    break;
			
			}
		}
	
	}

}
