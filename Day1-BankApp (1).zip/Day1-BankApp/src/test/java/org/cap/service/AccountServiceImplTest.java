package org.cap.service;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.TimeUnit;

import org.cap.dao.AccountDaoImpl;
import org.cap.dto.Account;
import org.cap.dto.Address;
import org.cap.dto.Customer;
import org.cap.exception.InsufficientBalanceException;
import org.cap.exception.InvalidInitialAmountException;
import org.cap.util.AccountUtil;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
@RunWith(Parameterized.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AccountServiceImplTest {

	AccountServiceImpl serviceimpl=new AccountServiceImpl();
	@BeforeEach
	public  void before()
	{ 
		// this @Before method is called each time before executing each test

		
       System.out.println("before");
		}
	
	@AfterEach
	public  void after()
	{ 
		// this @After method is called each time after executing each test
     System.out.println("after");
	
		}
	
	@Test
	@Order(4)
	@Disabled("this test is under development")
	void test() {
		AccountServiceImpl serviceimpl=new AccountServiceImpl();
		int expected=2;
		int actual=serviceimpl.addNumbers(1, 1);
		assertEquals(expected,actual);
	}
	
	
	@Test
	@Order(1)
	@DisplayName(" Testing valid customer")
	void validateAndCreateAccount() throws InvalidInitialAmountException {
		Address address=new Address("hyderabad");
		Customer customer=new Customer("anusha", address);
		Account account	=serviceimpl.addAccount(customer,10000 );
		System.out.println("account created succesfully");
		System.out.println("available balance" + account.getAmount());
	    assertNotNull(account);
		
	}

	@Test
	@Order(2)	
	@DisplayName(" Testing WithDraw")
	void withDraw() throws InsufficientBalanceException, InvalidInitialAmountException
	{	
		
		
		Account account=	serviceimpl.withdraw(0, 500);
		System.out.println("current balance" +account.getAmount());
		assertNotNull(account);
	}
	
	@Test
	@Order(3)
	@DisplayName(" Testing Deposit")
	void deposit()
	{
		
	Account account=	serviceimpl.deposit(0, 200);
	System.out.println("currentbalance" + account.getAmount());
		assertNotNull(account);
	}
	
	
	//parameterized tests allow a developer to run the same test over and over using different values
	
	
	@ParameterizedTest(name= "{index} - Run test with args = {0}")
	@ValueSource(ints= {1,2,3,4,5})
	 void testParameter(int args)
	{
		System.out.println(args);
		
}
	
	@BeforeAll
	public static void beforeClass()
	{ 
		// this @BeforeClass method is called only once  before executing  test cases

		Account account=new Account();
       AccountUtil accountutil=new AccountUtil();
       System.out.println("beforeclass");
		}
	
	@AfterAll
	public static void afterClass()
	{ 
		// this @AfterClass method is called only one time after executing all test cases
     System.out.println("afterclass");
	
    }
	
	@Test
	@Timeout(value=1000, unit=TimeUnit.MILLISECONDS)
	public void timeOutTest()
	{
		System.out.println("time out after 1000ms");
		
		
	}
	
	
}
