package org.cap.dto;

public class Customer {

	private String custName;
	private Address custAddress;
	
	
	
	
	public Customer(String custName, Address custAddress) {
		super();
		this.custName = custName;
		this.custAddress = custAddress;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Address getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(Address custAddress) {
		this.custAddress = custAddress;
	}
	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", custAddress=" + custAddress + "]";
	}
	
	
	
}
