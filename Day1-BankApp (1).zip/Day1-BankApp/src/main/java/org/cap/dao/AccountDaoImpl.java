package org.cap.dao;

import org.cap.dto.Account;
import org.cap.dto.Customer;

public class AccountDaoImpl implements AccountDao{
	Account account= new Account();
	@Override
	public boolean createAccount(Account account) {
		// TODO Auto-generated method stub
		System.out.println("in creat account");
		return true;
	}

	@Override
	public Account findAccountById(int accountNo) {
		// TODO Auto-generated method stub
		
		System.out.println(accountNo);
		
		if(account.getAccountNo()==accountNo)
			
	   return account;
		
		return null;
	}

	
}
