package org.cap.exception;

public class InvalidInitialAmountException extends Exception {

}
