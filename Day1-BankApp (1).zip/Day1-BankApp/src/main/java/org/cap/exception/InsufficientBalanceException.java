package org.cap.exception;

public class InsufficientBalanceException extends Exception {

}
