package org.cap.service;

import org.cap.dao.AccountDao;
import org.cap.dao.AccountDaoImpl;
import org.cap.dto.Account;
import org.cap.dto.Customer;
import org.cap.exception.InsufficientBalanceException;
import org.cap.exception.InvalidInitialAmountException;
import org.cap.util.AccountUtil;

public class AccountServiceImpl implements AcccountService{
	
	private AccountDao accountDao;
	private static Account account;

	
	public AccountServiceImpl(){}

	public AccountServiceImpl(AccountDao accountDao) {
		super();
		this.accountDao = accountDao;
	}
	

	@Override
	public Account addAccount(Customer customer, double amount) throws InvalidInitialAmountException {
		
		if(customer==null)
			throw new IllegalArgumentException();
		if(amount<500)
			throw new InvalidInitialAmountException();
		
		 account =new Account();
		account.setAccountNo(AccountUtil.generateAccountNumber());
		account.setCustomer(customer);
		account.setAmount(amount);

		AccountDaoImpl adi=new AccountDaoImpl();
		
		if(adi.createAccount(account))
		{	System.out.println(account);
			return account;}
		
		return null;
	}

	@Override
	public Account findAccountById(int accountNo) {
		System.out.println(account);
	if(account.getAccountNo()==accountNo)
	{
		System.out.println("in method");
		return account;
		
	}
	return null;
	}

	@Override
	public Account withdraw(int accountNo, double amount) throws InsufficientBalanceException {
		AccountServiceImpl imp=new AccountServiceImpl();
		

		Account account=imp.findAccountById(accountNo);
		
		System.out.println(account);
		
		if(account.getAmount()<amount)
			throw new InsufficientBalanceException();
		
		account.setAmount(account.getAmount()-amount);
		
		
		return account;
	}

	@Override
	public Account deposit(int accountNo, double amount) {
		AccountServiceImpl imp=new AccountServiceImpl();
		Account account=imp.findAccountById(accountNo);
		
		account.setAmount(account.getAmount()+amount);
		
		return account;
	}
	
	
	
	@Override
	public int addNumbers(int num1,int num2){
		return num1+num2;
	}
	
	
	
	
	
	
	
	
	

}
