package com.cg.retailservice;



public interface Retailstoreservice {
	public double calculateDiscounts(double price);
	public double calculateDiscountEmployees (double price);
	public double calculateDiscountAffilates(double price);
	public double calculateDiscountCustomers(double price);

}
