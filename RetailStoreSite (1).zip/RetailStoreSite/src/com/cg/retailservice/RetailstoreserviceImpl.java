package com.cg.retailservice;

import com.cg.retaildao.RetailstoreDao;
import com.cg.retaildao.RetailstoreDaoImpl;

public class RetailstoreserviceImpl implements Retailstoreservice {
    RetailstoreDao daoobject=new RetailstoreDaoImpl();
	
	@Override
	public double calculateDiscountEmployees(double price) {
		// TODO Auto-generated method stub
		return daoobject.calculateDiscountEmployee(price);
	}

	@Override
	public double calculateDiscountAffilates(double price) {
		// TODO Auto-generated method stub
		return daoobject.calculateDiscountAffilate(price);
	}

	@Override
	public double calculateDiscountCustomers(double price) {
		// TODO Auto-generated method stub
		return daoobject.calculateDiscountCustomer(price);
	}

	@Override
	public double calculateDiscounts(double price) {
		// TODO Auto-generated method stub
		return daoobject.calculateDiscount(price);
	}

		
 

}
