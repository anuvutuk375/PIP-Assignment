package com.cg.retaildao;


public interface RetailstoreDao {
	
	public double calculateDiscount(double price);
	public double calculateDiscountEmployee (double price);
	public double calculateDiscountAffilate(double price);
	public double calculateDiscountCustomer(double price);
	
	}

