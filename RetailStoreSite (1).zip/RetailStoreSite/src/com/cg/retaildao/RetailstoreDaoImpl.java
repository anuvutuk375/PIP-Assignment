package com.cg.retaildao;

public class RetailstoreDaoImpl implements RetailstoreDao{

	@Override
	public double calculateDiscount(double price) {
		// TODO Auto-generated method stub
		double discount=(price*5)/100;
		price=price-discount;
				return price;

	}
//calculating discount for employee
	@Override
	public double calculateDiscountEmployee(double price) {
		// TODO Auto-generated method stub
		double discount=(price*30)/100+((price*5)/100);
		price=price-discount;
		return price;
			}
//calculating discount for affiliates
	@Override
	public double calculateDiscountAffilate(double price) {
		// TODO Auto-generated method stub
		double discount=((price*10)/100)+((price*5)/100);
		price=price-discount;
		return price;
	}
//calculating discount for customer more than two years
	@Override
	public double calculateDiscountCustomer(double price) {
		// TODO Auto-generated method stub
		double discount=(price*5)/100+((price*5)/100);
		price=price-discount;
		return price;

	}

	
}
