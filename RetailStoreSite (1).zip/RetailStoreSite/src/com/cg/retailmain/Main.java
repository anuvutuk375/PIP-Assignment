package com.cg.retailmain;

import java.util.Scanner;

import com.cg.retailservice.Retailstoreservice;
import com.cg.retailservice.RetailstoreserviceImpl;

public class Main {
	public static void main(String[] args) {
		Retailstoreservice  serviceobj=new RetailstoreserviceImpl();
		Scanner scanner=new Scanner(System.in);
		int ch;
		while(true){
		System.out.println("Welcome to retail store.. \n the type of products purchased...\n 1.grocaries \n 2.others \n 3.exit");
		System.out.print("Enter your choice : ");
		ch = scanner.nextInt(); 
		//scanner.nextLine();
		switch(ch) {
		case 1:
			boolean flag=false;
			double price=scanner.nextDouble();
			double finalPrice=0;
				System.out.println("enter the price in $:");
				price=scanner.nextDouble();
			finalPrice=serviceobj.calculateDiscounts(price);
			System.out.println("your total bill is:"+ finalPrice);
		break;
		case 2: 
		boolean flag2=false;
		boolean flag3=false;
			System.out.println("enter the type of user: \n1.Employee   \n2.affiliate  \n3.customer for about 2 years \n4. new customer");
			int choice2=scanner.nextInt();
			scanner.nextLine();
			double prices=0;
			System.out.println("enter price:");
			price=scanner.nextDouble();
			switch(choice2) {
			case 1:
			   finalPrice=serviceobj.calculateDiscountEmployees(price);
			   System.out.println("your final price is:" + finalPrice);
			   break;
			case 2:
				   finalPrice=serviceobj.calculateDiscountAffilates(price);
				   System.out.println("your final price is:" + finalPrice);
				   break;
			case 3:
				   finalPrice=serviceobj.calculateDiscountCustomers(price);
				   System.out.println("your final price is:" + finalPrice);
				   break;
			case 4:
				   finalPrice=serviceobj.calculateDiscounts(price);
				   System.out.println("your final price is:" + finalPrice);
				   break;
				
			}break;
		case 3:
			System.out.println("thank you");
			System.exit(0);
			break;
			
		}
		}
		
		
			
		}
	}
	

	


